/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.groovy.ginq.provider.collection.runtime;

import java.io.Serial;
import java.util.stream.Stream;

/**
 * Represents group implementation
 *
 * @param <T> the type of element
 * @since 4.0.0
 */
class GroupImpl<T> extends QueryableCollection<T> implements Group<T> {
    @Serial private static final long serialVersionUID = 5737735821215711785L;

    /**
     * Creates a group backed by the supplied stream.
     *
     * @param sourceStream the group elements
     */
    GroupImpl(Stream<T> sourceStream) {
        super(sourceStream);
    }
}
