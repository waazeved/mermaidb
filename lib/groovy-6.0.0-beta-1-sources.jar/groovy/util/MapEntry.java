/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.util;

import org.codehaus.groovy.runtime.typehandling.DefaultTypeTransformation;

import java.util.Map;

/**
 * A Map.Entry implementation.
 */
public class MapEntry implements Map.Entry {

    private Object key;
    private Object value;

    /**
     * Creates a map entry with the supplied key and value.
     *
     * @param key the entry key
     * @param value the entry value
     */
    public MapEntry(Object key, Object value) {
        this.key = key;
        this.value = value;
    }

    /** {@inheritDoc} */
    @Override
    public boolean equals(Object that) {
        if (that instanceof MapEntry) {
            return equals((MapEntry) that);
        }
        return false;
    }

    /**
     * Compares this entry with another {@code MapEntry}.
     *
     * @param that the entry to compare with
     * @return {@code true} if both key and value are equal
     */
    public boolean equals(MapEntry that) {
        return DefaultTypeTransformation.compareEqual(this.key, that.key) && DefaultTypeTransformation.compareEqual(this.value, that.value);
    }

    /** {@inheritDoc} */
    @Override
    public int hashCode() {
        return hash(key) ^ hash(value);
    }

    /** {@inheritDoc} */
    @Override
    public String toString() {
        return key + ":" + value;
    }

    /** {@inheritDoc} */
    @Override
    public Object getKey() {
        return key;
    }

    /**
     * Updates the entry key.
     *
     * @param key the new key
     */
    public void setKey(Object key) {
        this.key = key;
    }

    /** {@inheritDoc} */
    @Override
    public Object getValue() {
        return value;
    }

    /** {@inheritDoc} */
    @Override
    public Object setValue(Object value) {
        this.value = value;
        return value;
    }

    /**
     * Helper method to handle object hashes for possibly null values
     */
    protected int hash(Object object) {
        return (object == null) ? 0xbabe : object.hashCode();
    }

}
